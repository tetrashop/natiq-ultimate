# 🚀 نطق مصطلح - راهنمای بهره‌برداری

## 📋 معرفی
سامانه هوشمند پرسش و پاسخ مبتنی بر مقالات با قابلیت‌های پیشرفته

## 🏗️ معماری
- **سرور مقالات** (پورت 3000): مدیریت و سرویس‌دهی مقالات
- **سرور پرسش و پاسخ** (پورت 3002): پردازش سوالات با الگوریتم‌های مختلف
- **الگوریتم‌ها**: Keyword-based, Semantic, Simple NLP, Auto-selection

## 🔧 مدیریت سامانه

### اسکریپت‌های اصلی:
1. **`manage-natiq.sh`** - مدیریت کامل سامانه
   ```bash
   ./manage-natiq.sh start      # شروع
   ./manage-natiq.sh stop       # توقف
   ./manage-natiq.sh status     # وضعیت
   ./manage-natiq.sh backup     # backup
   ./manage-natiq.sh monitor    # نظارت زنده
   ./manage-natiq.sh test       # تست کامل
