#!/bin/bash
echo "🛑 توقف نطق مصطلح..."
pkill -f "node.*natiq"
echo "✅ سیستم متوقف شد"
