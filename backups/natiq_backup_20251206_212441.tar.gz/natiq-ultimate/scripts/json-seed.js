/**
 * 🌱 تولید ۵۰ مقاله NLP فارسی با ذخیره‌سازی JSON
 */

const fs = require('fs');
const path = require('path');

// موضوعات NLP فارسی (50 موضوع)
const NLP_TOPICS = [
  'پردازش زبان طبیعی چیست؟',
  'تاریخچه NLP',
  'کاربردهای پردازش زبان طبیعی',
  'چالش‌های NLP برای زبان فارسی',
  'معماری سیستم‌های NLP',
  'پایپ‌لاین پردازش متن',
  'پیش‌پردازش متن فارسی',
  'نرمالایز کردن متن',
  'توکنایز کردن متن فارسی',
  'ریشه‌یابی کلمات فارسی',
  'حذف استاپ‌وردهای فارسی',
  'تشخیص بخش‌های گفتار',
  'تحلیل نحوی جمله',
  'تشخیص موجودیت‌های نام‌دار',
  'تحلیل وابستگی‌های نحوی',
  'تشخیص مرجع ضمیر',
  'استخراج روابط معنایی',
  'تشخیص احساسات متن',
  'تشخیص لحن متن',
  'تشخیص موضوع متن',
  'مدل‌های زبانی آماری',
  'مدل‌های n-gram',
  'مدل‌های زبانی عصبی',
  'Word Embeddings چیست؟',
  'Word2Vec برای فارسی',
  'GloVe برای زبان فارسی',
  'FastText و کاربردهای آن',
  'BERT و انقلاب در NLP',
  'معماری ترنسفورمر',
  'آشنایی با GPT',
  'RoBERTa و بهبودهای آن',
  'مدل‌های چندزبانه',
  'XLM-RoBERTa',
  'mBERT برای فارسی',
  'مدل‌های تولید متن',
  'T5: Text-to-Text Transfer',
  'BART برای خلاصه‌سازی',
  'دسته‌بندی متن فارسی',
  'کلاسیفایرهای متنی',
  'SVM برای طبقه‌بندی متن',
  'شبکه‌های عصبی برای NLP',
  'LSTM برای پردازش توالی',
  'GRU و کاربردهای آن',
  'شبکه‌های کانوولوشنی برای متن',
  'ترکیب CNN و LSTM',
  'آشنایی با Hugging Face',
  'استفاده از Transformers',
  'پایپ‌لاین Hugging Face',
  'تولید دیتاست فارسی',
  'نشانه‌گذاری دیتاست'
];

// تولید محتوای مقاله
function generateArticleContent(topic, id) {
  return `مقاله شماره ${id} با موضوع "${topic}"

## مقدمه
پردازش زبان طبیعی (Natural Language Processing) یا NLP، شاخه‌ای از هوش مصنوعی است که به تعامل بین کامپیوتر و زبان انسان می‌پردازد.

## اهمیت ${topic}
اهمیت "${topic}" در کاربردهای عملی آن نهفته است. از این تکنولوژی در موارد زیر استفاده می‌شود:
1. سیستم‌های جستجوی هوشمند
2. دستیارهای مجازی
3. تحلیل احساسات
4. ترجمه ماشینی
5. خلاصه‌سازی خودکار

## نتیجه‌گیری
"${topic}" فرصت‌های زیادی را برای محققان و توسعه‌دهندگان ایجاد کرده است.

---
*این مقاله توسط سیستم نطق مصطلح تولید شده است.*`;
}

// تولید slug
function generateSlug(text) {
  return text
    .replace(/[^\u0600-\u06FF\w\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-')
    .toLowerCase();
}

// ایجاد داده‌های نمونه
async function createJSONDatabase() {
  console.log('🌱 شروع تولید ۵۰ مقاله NLP فارسی...');
  
  const dataPath = path.join(__dirname, '../data/articles.json');
  const dataDir = path.dirname(dataPath);
  
  // ایجاد پوشه data اگر وجود ندارد
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  const categories = ['آموزش', 'پروژه', 'تحلیل', 'اخبار', 'کتابخانه', 'توسعه'];
  const tagsList = ['NLP', 'پردازش زبان طبیعی', 'هوش مصنوعی', 'فارسی', 'پایتون', 'یادگیری ماشین'];
  
  const articles = [];
  
  const startTime = Date.now();
  
  for (let i = 0; i < 50; i++) {
    const topic = NLP_TOPICS[i % NLP_TOPICS.length];
    const title = topic;
    const content = generateArticleContent(topic, i + 1);
    const slug = generateSlug(title);
    const excerpt = content.substring(0, 100) + '...';
    const category = categories[i % categories.length];
    const tags = [tagsList[i % tagsList.length], tagsList[(i + 1) % tagsList.length]];
    const views = Math.floor(Math.random() * 1000) + 100;
    const likes = Math.floor(Math.random() * 500) + 10;
    const shares = Math.floor(Math.random() * 100) + 5;
    const featured = i % 10 === 0;
    const created_at = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString();
    
    articles.push({
      id: i + 1,
      title,
      slug,
      content,
      excerpt,
      author: 'تیم نطق مصطلح',
      category,
      tags,
      views,
      likes,
      shares,
      featured,
      status: 'published',
      created_at
    });
    
    if ((i + 1) % 10 === 0) {
      console.log(`📝 تولید مقاله ${i + 1} از ۵۰`);
    }
  }
  
  // ذخیره در فایل JSON
  fs.writeFileSync(dataPath, JSON.stringify(articles, null, 2), 'utf8');
  
  const endTime = Date.now();
  const duration = ((endTime - startTime) / 1000).toFixed(2);
  
  console.log(`
✅ تولید داده‌ها کامل شد!
📊 تعداد مقالات: ${articles.length} مقاله
📁 مسیر فایل: ${dataPath}
⏱️  زمان اجرا: ${duration} ثانیه
    
🎉 سیستم آماده است! دستور زیر را اجرا کنید:
    
    node src/server/json-app.js
    `);
}

// اجرای اسکریپت
createJSONDatabase();
