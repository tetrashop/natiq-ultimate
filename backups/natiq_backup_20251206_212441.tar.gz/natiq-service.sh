#!/bin/bash
cd /data/data/com.termux/files/home/natiq-ultimate
node natiq-complete.cjs &
node qna-server-fixed.cjs &
